# Plants_Vs_Zombies
It is an implementation of game PlantsVsZombies in JAVA, using JAVAFX and OOPs concept with Low Level Design. 
Requirements for running:
1) JDK
3) JAVAFX
4) SCENEBUILDER

Run the main.java to run the game. 
