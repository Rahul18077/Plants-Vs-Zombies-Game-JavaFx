package application;

import javafx.animation.Animation;
import javafx.animation.ScaleTransition;
import javafx.animation.TranslateTransition;
import javafx.scene.image.ImageView;
import javafx.util.Duration;

public class zombies {
	protected int health;
	protected String type;
	protected int positionx;
	protected int positiony;
	protected ImageView ZombieImage;
	public ImageView getZombieImage() {
		return ZombieImage;
	}
	public void setZombieImage(ImageView zombieImage) {
		ZombieImage = zombieImage;
	}
	zombies(int health, String type,ImageView k){
		this.health=health;
		this.type=type;
		this.ZombieImage=k;
	}
	public void attack(int k) {
		TranslateTransition s1=new TranslateTransition();
		s1.setNode(ZombieImage);
		if(k==0) { //zombie moves
			s1.setByX(ZombieImage.getLayoutX()-80);
			//s1.setCycleCount(Animation.INDEFINITE);
			s1.setDuration(Duration.seconds(3));
			//s1.setNode(ZombieImage);
			s1.play();
		}else if(k==1) { //zombie pause to eat plant
			s1.pause();
			s1.setDelay(Duration.seconds(4));
			s1.setByX(-600);
			s1.setDuration(Duration.seconds(4));
			s1.play();
		}else if(k==2) {
			s1.pause();
		}
	}
}
class normal_zombie extends zombies{

	normal_zombie(int health, String type,ImageView ZombieImage) {
		super(health, type, ZombieImage);
		// TODO Auto-generated constructor stub
	}

}
class bucket extends zombies{

	bucket(int health, String type,ImageView z) {
		super(health, type,z);
		// TODO Auto-generated constructor stub
	}
}
class cone extends zombies{

	cone(int health, String type,ImageView z) {
		super(health, type,z);
		// TODO Auto-generated constructor stub
	}
}
class flag_zombie extends zombies{

	flag_zombie(int health, String type,ImageView z) {
		super(health, type,z);
		// TODO Auto-generated constructor stub
	}
}
class shield_zombie extends zombies{

	shield_zombie(int health, String type,ImageView z) {
		super(health, type,z);
		// TODO Auto-generated constructor stub
	}
}