package application;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import javafx.animation.Animation;
import javafx.animation.AnimationTimer;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Cursor;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.util.Duration;

public class levels extends Application{
	private static double time;
	private static Pane pane=new Pane();
	Stage level_stage=new Stage();
	Timer mytimer=new Timer();
	int totalsunpoint=0;
	public static ArrayList<plants> k3;
	private static double SceneX,SceneY,lateX,lateY,usex,usey,first;
	private static boolean res=false;
	public static ArrayList<plants> attacking_plants=new ArrayList<plants>();
	public player currentplayer;
	/////
	
	
	public player getCurrentplayer() {
		return currentplayer;
	}

	public void setCurrentplayer(player currentplayer) {
		this.currentplayer = currentplayer;
	}
	EventHandler<MouseEvent> ImagePress= 
	        new EventHandler<MouseEvent>() {
	 
	        @Override
	        public void handle(MouseEvent t) {
	           SceneX = t.getSceneX();
	            SceneY = t.getSceneY();
	            first=SceneX;
	            lateX = ((ImageView)(t.getSource())).getTranslateX();
	            lateY = ((ImageView)(t.getSource())).getTranslateY();
	        }
	    };
	     
	    EventHandler<MouseEvent> event5 = 
		        new EventHandler<MouseEvent>() {
		 
		        @Override
		        public void handle(MouseEvent t) {
		        	ImageView k1=(ImageView)t.getSource();
		        pane.getChildren().remove(k1);
		        	//k1.setVisible(false);
		          callrelease(usex,usey,first,k3);
		         
		        }
		    };
	    EventHandler<MouseEvent> ImageDrag = 
	        new EventHandler<MouseEvent>() {
	 
	        @Override
	        public void handle(MouseEvent t) {
	            double offsetX = t.getSceneX() -SceneX;
	            double offsetY = t.getSceneY() - SceneY;
	            double newlateX = lateX + offsetX;
	            double newlateY = lateY + offsetY;
	            usex=newlateX;
	            usey=newlateY;
	            res=true;
	            
	            ((ImageView)(t.getSource())).setTranslateX(newlateX);
	            ((ImageView)(t.getSource())).setTranslateY(newlateY);
	        }
	    };
	    
	    
	    
	    public void callrelease( double x,double y,double f,ArrayList<plants> s){
	    	int j=0;
	    	if(usey<130 || (usey==130) || (usey>130 && usey<180 )) {
	    		usey=130;
	    	}
	    	else if(usey<230 || (usey==230) || (usey>230 && usey<280 )) {
	    		usey=230;
	    	}
	    	else if(usey<330 || (usey==330) || (usey>330 && usey<380 )) {
	    		usey=330;
	    	}
	    	else if(usey<430 || (usey==430) || (usey>430 && usey<480 )) {
	    		usey=430;
	    	}
	    	
	    
	    	if(f<100) {
	    		
	    		ImageView k=new ImageView(s.get(0).Imageofplant);
				pane.getChildren().add(k);
				k.setCursor(Cursor.HAND);
				 k.setOnMousePressed(ImagePress);
				
				 k.setOnMouseDragged(ImageDrag);
				k.setOnMouseReleased(event5);
				k.setX(k.getX()+j);
				Label ax=new Label();
				ax.setText(Integer.toString(s.get(0).getPrice()));
				pane.getChildren().add(ax);
				ax.setLayoutX(35+j);
				ax.setLayoutY(100);
				ax.getBorder();
				ax.setFont(Font.font("Arial",20));
				ax.setTextFill(Color.web("#FFFFFF"));
				
				//System.out.println(ax.getText());
				ax.setVisible(true);
				System.out.println("x "+usex+" y "+usey+" f "+f);
				ImageView pea=new ImageView(new Image("file:PeaShooter1.png"));
				    pea.setX(usex);
				    pea.setY(usey);
				    int newx=(int) usex;
				    int newy=(int) usey;
				    plants p1=new normal_shooter("NORMAL_SHOOTER", newx,newy,450,50,new Image("file:Peashooter1.png"));
				    attacking_plants.add(p1);
				    
				    pane.getChildren().add(pea);
				    pea.setVisible(true);
				
	    	}
	    	else if(f>=100 && f<200) {
	    		j=100;
	    		ImageView k=new ImageView(s.get(1).Imageofplant);
				pane.getChildren().add(k);
				k.setCursor(Cursor.HAND);
				 k.setOnMousePressed(ImagePress);
				 System.out.println("x "+usex+" y "+usey+" f "+f);
				 k.setOnMouseDragged(ImageDrag);
				k.setOnMouseReleased(event5);
				k.setX(k.getX()+j);
				Label ax=new Label();
				ax.setText(Integer.toString(s.get(1).getPrice()));
				pane.getChildren().add(ax);
				ax.setLayoutX(35+j);
				ax.setLayoutY(100);
				ax.getBorder();
				ax.setFont(Font.font("Arial",20));
				ax.setTextFill(Color.web("#FFFFFF"));
			
				//System.out.println(ax.getText());
				ax.setVisible(true);
				ImageView pea=new ImageView(new Image("file:SunFlower1.png"));
			    pea.setX(usex+100);
			    pea.setY(usey);
			    int newx=(int) usex;
			    int newy=(int) usey;
			    plants a2=new bigsungiver("BIG_SUNGIVER",newx+100,newy,450,50,new Image("file:SunFlower1.png"));
			    attacking_plants.add(a2);
			    pane.getChildren().add(pea);
			    pea.setVisible(true);
	    	}
	    	else if(f>=200 && f<300) {
	    		j=200;
	    		ImageView k=new ImageView(s.get(2).Imageofplant);
				pane.getChildren().add(k);
				k.setCursor(Cursor.HAND);
				 k.setOnMousePressed(ImagePress);
				 System.out.println("x "+usex+" y "+usey+" f "+f);
				 k.setOnMouseDragged(ImageDrag);
				k.setOnMouseReleased(event5);
				k.setX(k.getX()+j);
				Label ax=new Label();
				ax.setText(Integer.toString(s.get(2).getPrice()));
				pane.getChildren().add(ax);
				ax.setLayoutX(35+j);
				ax.setLayoutY(100);
				ax.getBorder();
				ax.setFont(Font.font("Arial",20));
				ax.setTextFill(Color.web("#FFFFFF"));
			
				//System.out.println(ax.getText());
				ax.setVisible(true);
				ImageView pea=new ImageView(new Image("file:smallwall.png"));
			    pea.setX(usex+200);
			    pea.setY(usey);
			    int newx=(int) usex;
			    int newy=(int) usey;
			    plants a3=new wallnut("WALLNUT",newx+200,newy,350,50,new Image("file:smallwall.png"));
			    attacking_plants.add(a3);
			    pane.getChildren().add(pea);
			    pea.setVisible(true);
	    	}
	    	else if(f>=300 && f<400) {
	    		j=300;
	    		System.out.println("x "+usex+" y "+usey+" f "+f);
	    		ImageView k=new ImageView(s.get(3).Imageofplant);
				pane.getChildren().add(k);
				k.setCursor(Cursor.HAND);
				 k.setOnMousePressed(ImagePress);
				
				 k.setOnMouseDragged(ImageDrag);
				k.setOnMouseReleased(event5);
				k.setX(k.getX()+j);
				Label ax=new Label();
				ax.setText(Integer.toString(s.get(3).getPrice()));
				pane.getChildren().add(ax);
				ax.setLayoutX(35+j);
				ax.setLayoutY(100);
				ax.getBorder();
				ax.setFont(Font.font("Arial",20));
				ax.setTextFill(Color.web("#FFFFFF"));
			
				//System.out.println(ax.getText());
				ax.setVisible(true);
				ImageView pea=new ImageView(new Image("file:tallwall.png"));
			    pea.setX(usex+300);
			    pea.setY(usey);
			    int newx=(int) usex;
			    int newy=(int) usey;
			    plants a4=new bigwallnut("BIGWALLNUT",newx+300,newy,300,75,new Image("file:tallwall.png"));
			    attacking_plants.add(a4);
			    pane.getChildren().add(pea);
			    pea.setVisible(true);
	    	}
	    	else if(f>=400 && f<500) {
	    		j=400;
	    		ImageView k=new ImageView(s.get(4).Imageofplant);
				pane.getChildren().add(k);
				k.setCursor(Cursor.HAND);
				 k.setOnMousePressed(ImagePress);
				 System.out.println("x "+usex+" y "+usey+" f "+f);
				 k.setOnMouseDragged(ImageDrag);
				k.setOnMouseReleased(event5);
				k.setX(k.getX()+j);
				Label ax=new Label();
				ax.setText(Integer.toString(s.get(4).getPrice()));
				pane.getChildren().add(ax);
				ax.setLayoutX(35+j);
				ax.setLayoutY(100);
				ax.getBorder();
				ax.setFont(Font.font("Arial",20));
				ax.setTextFill(Color.web("#FFFFFF"));
			
				//System.out.println(ax.getText());
				ax.setVisible(true);
				ImageView pea=new ImageView(new Image("file:cherry.png"));
			    pea.setX(usex+400);
			    pea.setY(usey);
			    int newx=(int) usex;
			    int newy=(int) usey;
				plants a5=new cherrybomb("CHERRYBOMB",newx+400,newy,200,75,new Image("file:cherry.png"));
			    attacking_plants.add(a5);
			    pane.getChildren().add(pea);
			    pea.setVisible(true);
	    	}
	    	printplants(attacking_plants);
	    }
	
	public void printplants(ArrayList<plants> p) {
		for(int i=0;i<p.size();i++) {
			System.out.println("index = "+i+" "+p.get(i).type);
		}
	}
		
	//////
	@Override
	
	
	public void start(Stage arg0) throws Exception {
		// TODO Auto-generated method stub
		k3=getPlant(1);
		pane.setPadding(new Insets(50,50,50,50));
		Image i=new Image("file:lawn12.png");
		ImageView s=new ImageView(i);
		s.autosize();
		pane.getChildren().add(s);
		ArrayList<plants> k=getPlant(1);	//arraylist for type of plant
		make_Plantpanel(k);					//making purchase panel
		addingLawnMower(new Image("file:Lawn_mower_2.PNG.png"));
		//GridPane.setConstraints(m1, 1, 1);
		plants a1=new normal_shooter("NORMAL_SHOOTER",100,140,350,100,new Image("file:Peashooter1.png"));
		a1.setWorkingpane(pane);
		ImageView temp=new ImageView(a1.Imageofplant);
		temp.setX(a1.positionx);			
		temp.setY(a1.positiony);
		pane.getChildren().add(temp);
		Button bb=new Button("PAUSE");
		bb.setLayoutX(700);
		ArrayList<zombies> k123=makezombies(2);		//all zombies for the current level
		createZombies(k123);
		ArrayList<zombies> currentzombies=new ArrayList<zombies>();  //all zombies for plane
		addzombie(k123,currentzombies);
		addzombie(k123,currentzombies);
		//bb.setLayoutX(700);
		ArrayList<zombies> resultant=makezombies(1);
		EventHandler<ActionEvent> event1 = new EventHandler<ActionEvent>() { 
            public void handle(ActionEvent e) 
            { 
               //System.out.println(peashooter_example.getX()+"     ");
            } 
        }; 
		
		EventHandler<ActionEvent> event = new EventHandler<ActionEvent>() { 
            public void handle(ActionEvent e) 
            { 
               try {
				makeStage();
				
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
            } 
        };

		bb.setOnAction(event);
		pane.getChildren().add(bb);
		Scene s1=new Scene(pane,800,600);
		s.setFitHeight(s1.getHeight());
		s.setFitWidth(s1.getWidth());
		
		Timeline timeline=new Timeline(new KeyFrame(
				Duration.seconds(2),
				(evt)->{
					Random random = new Random();
					if(attacking_plants.size()!=0) {
						for(int j=0;j<attacking_plants.size();j++) {
							System.out.println(attacking_plants.get(j).type+"  "+attacking_plants.get(j).getPositionx()+" "+attacking_plants.get(j).positiony);
						}
					}
					if(k123.size()!=0) {
					addzombie(k123,currentzombies);
					}
	                currentzombies.get(random.nextInt(currentzombies.size())).attack(0);
	                a1.attack(currentzombies);
	                
				}
				));
		timeline.setCycleCount(Animation.INDEFINITE);
		timeline.play();
		if(k123.size()==0) {
			timeline.pause();
		}
 		level_stage.setScene(s1);
		level_stage.show();
		
	}
	//public void setzombie(zombies s,)
	public static void main(String[] args) {
		launch(args);
	}
	public void createlevel(int i) {
		
	}
	public void plantattack(ArrayList<plants> a,ArrayList<zombies> b) {
		Random r=new Random();
		int i=r.nextInt(a.size());
		for(int j=0;j<i;i++) {
			int k=r.nextInt(a.size());
			a.get(k).attack(b);
		}
	}
	public void addzombie(ArrayList<zombies> zomb,ArrayList<zombies> second) {
		Random num=new Random();
		int k=num.nextInt(zomb.size());
		second.add(zomb.get(k));
		
		pane.getChildren().add(second.get(second.size()-1).ZombieImage);
		zomb.remove(k);
	}
	public ArrayList<zombies> makezombies(int k) {
		ArrayList<zombies> s=new ArrayList<zombies>();
		if(k==1) {
			//k.size()
			Random a=new Random();
			for(int i=0;i<7;i++) {
				int num=a.nextInt(2);
				if(num==0) {
					zombies ax=new normal_zombie(100,"normal_zombie",new ImageView(new Image("file:Zombie1.png")));
					s.add(ax);
				}else if(num==1) {
					zombies a2=new flag_zombie(100,"flag_zombie",new ImageView(new Image("file:flag.png")));
					s.add(a2);
				}
			}
		}if(k==2) {
			Random a=new Random();
			for(int i=0;i<12;i++) {
				int num=a.nextInt(3);
				if(num==0) {
					s.add(new normal_zombie(100,"normal_zombie",new ImageView(new Image("file:Zombie1.png"))));
				}else if(num==1) {
					s.add(new flag_zombie(100,"flag_zombie",new ImageView(new Image("file:flag.png"))));
				}else if(num==2) {
					s.add(new bucket(150,"bucket",new ImageView(new Image("file:bucket.png"))));
				}
			}
		}else if(k==3) {
			Random a=new Random();
			for(int i=0;i<16;i++) {
				int num=a.nextInt(4);
				if(num==0) {
					s.add(new normal_zombie(100,"normal_zombie",new ImageView(new Image("file:Zombie1.png"))));
				}else if(num==1) {
					s.add(new flag_zombie(100,"flag_zombie",new ImageView(new Image("file:flag.png"))));
				}else if(num==2) {
					s.add(new bucket(150,"bucket",new ImageView(new Image("file:bucket.png"))));
				}else if(num==3) {
					s.add(new cone(180,"cone",new ImageView(new Image("file:cone.png"))));
				}
			}
		}else if(k==4) {
			Random a=new Random();
			for(int i=0;i<22;i++) {
				int num=a.nextInt(4);
				if(num==0) {
					//ax=k.get(new normal_zombie(100,"normal_zombie",new ImageView(new Image("file:Zombie1.png"))));
					s.add(new normal_zombie(100,"normal_zombie",new ImageView(new Image("file:Zombie1.png"))));
				}else if(num==1) {
					s.add(new flag_zombie(100,"flag_zombie",new ImageView(new Image("file:flag.png"))));
				}else if(num==2) {
					s.add(new bucket(150,"bucket",new ImageView(new Image("file:bucket.png"))));
				}else if(num==3) {
					s.add(new cone(180,"cone",new ImageView(new Image("file:cone.png"))));
				}else if(num==4) {
					s.add(new shield_zombie(200,"shield_zombie",new ImageView(new Image("file:screen.png"))));
				}
			}
		}
		return s;
	}
	public void make_Plantpanel(ArrayList<plants> s) {
		int j=0;
		for(int i=0;i<s.size();i++) {
			ImageView k=new ImageView(s.get(i).Imageofplant);
			pane.getChildren().add(k);
			k.setCursor(Cursor.HAND);
			 k.setOnMousePressed(ImagePress);
			
			 k.setOnMouseDragged(ImageDrag);
			k.setOnMouseReleased(event5);
			k.setX(k.getX()+j);
			Label ax=new Label();
			ax.setText(Integer.toString(s.get(i).getPrice()));
			pane.getChildren().add(ax);
			ax.setLayoutX(35+j);
			ax.setLayoutY(100);
			ax.getBorder();
			ax.setFont(Font.font("Arial",20));
			ax.setTextFill(Color.web("#FFFFFF"));
		
			//System.out.println(ax.getText());
			ax.setVisible(true);

			j+=100;
		}
	}
	
	public ArrayList<plants> getPlant(int i) {
		ArrayList<plants> req=new ArrayList<plants>();
		if(i==1) {
			plants a1=new normal_shooter("NORMAL_SHOOTER",100,610,450,50,new Image("file:Peashooter1.png"));
			plants a2=new bigsungiver("BIG_SUNGIVER",100,610,450,50,new Image("file:SunFlower1.png"));
			req.add(a1);
			req.add(a2);
		}else if(i==2) {
			plants a1=new normal_shooter("NORMAL_SHOOTER",100,610,450,50,new Image("file:Peashooter1.png"));
			plants a2=new bigsungiver("BIG_SUNGIVER",100,600,400,50,new Image("file:SunFlower1.png"));
			plants a3=new wallnut("WALLNUT",150,510,350,50,new Image("file:smallwall.png"));
			req.add(a1);
			req.add(a2);
			req.add(a3);
		}else if(i==3) {
			plants a1=new normal_shooter("NORMAL_SHOOTER",100,610,450,50,new Image("file:Peashooter1.png"));
			plants a2=new bigsungiver("BIG_SUNGIVER",100,600,400,50,new Image("file:SunFlower1.png"));
			plants a3=new wallnut("WALLNUT",150,510,350,50,new Image("file:smallwall.png"));
			plants a4=new bigwallnut("BIGWALLNUT",250,400,300,75,new Image("file:tallwall.png"));
			req.add(a1);
			req.add(a2);
			req.add(a3);
			req.add(a4);
		}else if(i==4) {
			plants a1=new normal_shooter("NORMAL_SHOOTER",100,610,450,50,new Image("file:Peashooter1.png"));
			plants a2=new bigsungiver("BIG_SUNGIVER",100,600,400,50,new Image("file:SunFlower1.png"));
			plants a3=new wallnut("WALLNUT",150,510,350,50,new Image("file:smallwall.png"));
			plants a4=new bigwallnut("BIGWALLNUT",250,400,300,75,new Image("file:tallwall.png"));
			plants a5=new cherrybomb("CHERRYBOMB",0,300,200,75,new Image("file:cherry.png"));
			req.add(a1);
			req.add(a2);
			req.add(a3);
			req.add(a4);
			req.add(a5);
		}else {
			plants a1=new normal_shooter("NORMAL_SHOOTER",100,610,450,100,new Image("file:Peashooter1.png"));
			plants a2=new bigsungiver("BIG_SUNGIVER",100,600,400,50,new Image("file:SunFlower1.png"));
			plants a3=new wallnut("WALLNUT",150,510,350,75,new Image("file:smallwall.png"));
			plants a4=new bigwallnut("BIGWALLNUT",250,400,300,100,new Image("file:tallwall.png"));
			plants a5=new cherrybomb("CHERRYBOMB",0,300,200,125,new Image("file:cherry.png"));
			plants a6=new triple_shooter("TRIPLE_SHOOTER",150,200,100,150,new Image("file:Threepeater1.png"));
			req.add(a1);
			req.add(a2);
			req.add(a3);
			req.add(a4);
			req.add(a5);
			req.add(a6);
		}
	return req;
	}
	public void createZombies(ArrayList<zombies>  a) {
		int j=50;
		int x=750;
		for(int i=0;i<a.size();i++) {
			if(i%4==0) {
				j=50;
			}
			zombies zomb=a.get(i);
			zomb.getZombieImage().setFitHeight(100);
			zomb.getZombieImage().setFitWidth(100);
			zomb.getZombieImage().setX(x);
			zomb.positionx=x;
			zomb.positiony=j+100;
			zomb.getZombieImage().setY(j+100);
			//pane.getChildren().add(zomb.ZombieImage);
			j+=100;
		}
	}
	public void setcircle(ImageView k,Circle circle) {
		circle.setCenterX(k.getX()+50);
		circle.setCenterY(k.getY()+40);
	}
	public void attacking_plant(Circle circle) {
	    //double k=a.getLayoutX();
		//a.setLayoutX(k-10);
	    circle.setCenterX(circle.getCenterX()+1);
	}
	public void addingLawnMower(Image k) {
		int x=100;
		for(int i=0;i<4;i++) {
			ImageView s=new ImageView(k);
			//s.setLayoutX(100);
			//s.setLayoutY(100);
			s.setFitHeight(70);
			s.setFitWidth(80);
			s.setY(100+x);
			s.setX(-10);
			x+=100;
			pane.getChildren().add(s);
		}
	}
	public void makeStage() throws FileNotFoundException{
		Pane T=new Pane();
		Stage new1=new Stage();
        Image image = new Image("file:Pause.jpeg");
        ImageView k=new ImageView(image);
        T.getChildren().add(k);
        Button a1=new Button("Save");
        EventHandler<ActionEvent> event1 = new EventHandler<ActionEvent>() { 
            public void handle(ActionEvent e) 
            { 
               try {
            	   new1.close();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
            } 
        }; 
        a1.setOnAction(event1);
        a1.setLayoutX(135);
        Button a2=new Button("Continue");
        
        EventHandler<ActionEvent> event2 = new EventHandler<ActionEvent>() { 
            public void handle(ActionEvent e) 
            { 
               try {
            	   new1.close();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
            } 
        };
        a2.setOnAction(event2);
        Button a3=new Button("Exit");
        EventHandler<ActionEvent> event3 = new EventHandler<ActionEvent>() { 
            public void handle(ActionEvent e) 
            { 
               try {
				System.exit(0);
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
            } 
        };
        a3.setOnAction(event3);
        a2.setLayoutX(135);
        a3.setLayoutX(135);
        a1.setLayoutY(0);
        a2.setLayoutY(90);
        a3.setLayoutY(175);
        T.getChildren().add(a1);
        T.getChildren().add(a2);
        T.getChildren().add(a3);
        Scene s2=new Scene(T,300,200);
        new1.setScene(s2);
        new1.show();
	}
}
