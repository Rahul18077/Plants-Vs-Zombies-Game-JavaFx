package application;

import java.io.Serializable;
import java.util.ArrayList;

public class player implements Serializable{
	private String name;
	private int level;
	private int suntoken;
	ArrayList<plants> plantlist;
	ArrayList<zombies> zombielist;
	public player(String name2, int level2) {
		// TODO Auto-generated constructor stub
	}
	public void addzomb(zombies a) {
		zombielist.add(a);
	}
	public void addplant(plants a) {
		plantlist.add(a);
	}
	public ArrayList<plants> getPlantlist() {
		return plantlist;
	}
	public void setPlantlist(ArrayList<plants> plantlist) {
		this.plantlist = plantlist;
	}
	public ArrayList<zombies> getZombielist() {
		return zombielist;
	}
	public void setZombielist(ArrayList<zombies> zombielist) {
		this.zombielist = zombielist;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getLevel() {
		return level;
	}
	public void setLevel(int level) {
		this.level = level;
	}
	public int getSuntoken() {
		return suntoken;
	}
	public void setSuntoken(int suntoken) {
		this.suntoken = suntoken;
	}
}
