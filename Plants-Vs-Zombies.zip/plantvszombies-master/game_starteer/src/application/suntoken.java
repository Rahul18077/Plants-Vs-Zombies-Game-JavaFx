package application;

import javafx.scene.image.ImageView;

public class suntoken {
	ImageView sunImage;
	suntoken(ImageView a){
		this.sunImage=a;
	}
	public ImageView getSunImage() {
		return sunImage;
	}
	public void setSunImage(ImageView sunImage) {
		this.sunImage = sunImage;
	}
}
